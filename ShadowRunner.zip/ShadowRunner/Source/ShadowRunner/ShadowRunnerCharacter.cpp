#include "ShadowRunnerCharacter.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "Components/InputComponent.h"

AShadowRunnerCharacter::AShadowRunnerCharacter()
{
    PrimaryActorTick.bCanEverTick = true;
}

void AShadowRunnerCharacter::BeginPlay()
{
    Super::BeginPlay();
}

void AShadowRunnerCharacter::Tick(float DeltaTime)
{
    Super::Tick(DeltaTime);
}

void AShadowRunnerCharacter::SetupPlayerInputComponent(UInputComponent* PlayerInputComponent)
{
    Super::SetupPlayerInputComponent(PlayerInputComponent);
    PlayerInputComponent->BindAxis("MoveForward", this, &AShadowRunnerCharacter::MoveForward);
    PlayerInputComponent->BindAxis("MoveRight", this, &AShadowRunnerCharacter::MoveRight);
    PlayerInputComponent->BindAction("Jump", IE_Pressed, this, &AShadowRunnerCharacter::StartJump);
    PlayerInputComponent->BindAction("Jump", IE_Released, this, &AShadowRunnerCharacter::StopJump);
    PlayerInputComponent->BindAction("Slide", IE_Pressed, this, &AShadowRunnerCharacter::Slide);
}

void AShadowRunnerCharacter::MoveForward(float Value)
{
    AddMovementInput(GetActorForwardVector(), Value);
}

void AShadowRunnerCharacter::MoveRight(float Value)
{
    AddMovementInput(GetActorRightVector(), Value);
}

void AShadowRunnerCharacter::StartJump()
{
    bPressedJump = true;
}

void AShadowRunnerCharacter::StopJump()
{
    bPressedJump = false;
}

void AShadowRunnerCharacter::Slide()
{
    GetCharacterMovement()->MaxWalkSpeed = 1200.f;
}
